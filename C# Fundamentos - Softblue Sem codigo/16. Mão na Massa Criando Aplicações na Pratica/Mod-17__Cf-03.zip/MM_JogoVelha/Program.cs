﻿using System;

namespace Softblue
{
	class Program
	{
		static void Main()
		{
			// Instancia o jogo e inicia.
			Game game = new Game();
			game.Play();
		}
	}
}
