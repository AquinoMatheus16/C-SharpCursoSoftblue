﻿using System;

namespace Softblue
{
	class Program
	{
		static void Main()
		{
			// Inicia a execução do programa.
			SurveyUI ui = new SurveyUI();
			ui.Start();
		}
	}
}
